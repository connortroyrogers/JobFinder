

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		ArrayList<Employer> employers = new ArrayList<Employer>();
		ArrayList<JobSeeker> jobSeekers = new ArrayList<JobSeeker>();
		System.out.println("~ Welcome to Job Search App ~");
		
		boolean finalInputComplete = false;
		Scanner in = new Scanner(System.in);
		
		
		
		while (!finalInputComplete) {
			System.out.print("Enter J for jobseeker mode, E for employer mode: ");
			String choice1 = in.nextLine();
			if (!(choice1.equals("J") || choice1.equals("E"))) {
        System.out.println("Invalid input");
        continue;
      }
			System.out.println("To register, enter R. To login, enter L");
			String choice2 = in.nextLine();
			if (!(choice2.equals("L") || choice2.equals("R"))) {
        System.out.println("Invalid input");
        continue;
      }
			System.out.print("Enter username: ");
			String inUsername = in.nextLine();
			System.out.print("Enter password: ");
			String inPassword = in.nextLine();
			
			boolean userNameTaken = false;
			
			switch (choice1) {
			case "J":
				for (JobSeeker i : jobSeekers) {
					if (i.getUsername().equals(inUsername)) { userNameTaken = true; }
				}
				break;
			case "E":
				for (Employer i : employers) {
					if (i.getUsername().equals(inUsername)) { userNameTaken = true; }
				}
				break;
			}
			
			switch (choice2) {
			case "R":
        if (userNameTaken) {
          System.out.println("Username taken");
          continue;
        } else {
          System.out.println("Please enter full name: ");
          String inName = in.nextLine();
          switch (choice1) {
            case "J":
              System.out.println("Please enter address");
              String inAddress = in.nextLine();
              System.out.println("Please enter phone #");
              String inPhoneNumber = in.nextLine();
              JobSeeker inJobSeeker = new JobSeeker(inName, inUsername, inPassword, inAddress, inPhoneNumber);
              jobSeekers.add(inJobSeeker);
              System.out.println("Job seeker created. Add skills/past employment after login");
              System.out.println("Returning to login menu...");
              continue;
            case "E":
              Employer inEmployer = new Employer(inName, inUsername, inPassword);
              employers.add(inEmployer);
              System.out.println("Employer created.");
              System.out.println("Returning to login menu...");
              continue;
          }
        }
				break;
			case "L":
				//login menu
        String input = "";
        //employer perspective
        if(choice1.equals("E")){
          while(!input.equals("5")){
            System.out.println("Please choose an option:");
            System.out.println("1. Create new job");
            System.out.println("2. Update job");
            System.out.println("3. View jobs");
            System.out.println("4. Browse job seekers");
            System.out.println("5. Sign out");
            System.out.println("6. Delete account");
            input = in.nextLine();

            if(input.equals("1")){
              
            }
            else if(input.equals("2")){
              
            }
            else if(input.equals("3")){
              
            }
            else if(input.equals("4")){
              
            }
            else if(input.equals("5")){
              
            }
            else if(input.equals("6")){
              
            }
            else {
              System.out.println("Invalid input");
            }

          }
          //job seeker perspective
          if(choice1.equals("J")){
            while(!input.equals("5")){
              System.out.println("Please choose an option:");
              System.out.println("1. View profile");
              System.out.println("2. Update profile");
              System.out.println("3. Browse jobs");
              System.out.println("4. View job status");
              System.out.println("5. Sign out");
              System.out.println("6. Delete account");
              input = in.nextLine();

              if(input.equals("1")){
                
              }
              else if(input.equals("2")){
                
              }
              else if(input.equals("3")){
                
              }
              else if(input.equals("4")){
                
              }
              else if(input.equals("5")){
                
              }
              else if(input.equals("6")){
                
              }
              else {
                System.out.println("Invalid input");
              }

            }
          break;
        }
			
      
 		}
		

	}

}

  }
}








