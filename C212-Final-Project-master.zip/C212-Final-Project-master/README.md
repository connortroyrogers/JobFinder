Project Name:
Job Search App.         

Members:
Connor Rogers, Aaryana Rajanala, Austin Gineris, Nick Emerson.         

# README
- Run main method in Main.java
- Menus will instruct user which keys to input
- To have proper state persistence, make sure to exit program with 'Q' command at proper menu
- State is saved in employers.ser and jobSeekers.ser. For running via java command, location is same directory
  - For Eclipse, it is project directory

# Member Resources
Diagraming Collaboration:
https://lucid.app/lucidchart/invitations/accept/49cfc9bf-7e1b-4c9b-8b06-773059022520?viewport_loc=-11%2C-11%2C2219%2C1065%2C0_0

IDE Collaboration:
https://replit.com/join/jccbnnqf-nemerson7

